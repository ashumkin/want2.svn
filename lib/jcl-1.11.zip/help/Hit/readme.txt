========================================================================
JEDI HtmlHelp INCLUSION TOOL
ALPHA 2
========================================================================

* Installation

- Compile and run HelpTool.dpr
- Add as many chm files as you want.
- Open the package JHIT.dpr
- Install the package 

Have fun!
